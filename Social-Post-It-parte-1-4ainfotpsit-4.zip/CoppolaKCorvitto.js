let fs = require('fs') //richiama fs

function addElementToJSON(jsonData, element) {
  jsonData.push(element) //aggiunge l'oggetto element al json in modo da gestire tutte le informazioni in un oggetto
}

function writeFileJSON(file, dataJSON) { //queste due funzioni consentono la scrittura e la lettura di file JSON 
  
  fs.writeFile(file, JSON.stringify(dataJSON), (err) => { //se non ci sono errori manda un messaggio di conferma
    if (err) {
      throw err;
    } else
      console.log('i dati li ho scritti nel file person.json');
  })
}

function readFile(percorsoFile) {
  var data = fs.readFileSync(percorsoFile, "utf8");//La funzione utilizza il "fs" per leggere il contenuto del file JSON 
  console.log("procedimento completato!");//lettura file completata
  return JSON.parse(data);
}


module.exports = { addElementToJSON: addElementToJSON, writeFileJSON: writeFileJSON, readFile: readFile } //permette di aggiungere scrivere e leggere il json