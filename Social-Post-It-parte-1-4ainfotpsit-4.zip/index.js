
const path = require('path');//richiama il modulo "path" che ti permette di lavorare con percorsi di file
const express = require('express'); //richiamo 'express' che ci permette di creare un server web.

const bodyParser = require('body-parser');//richiamo 'body-parser' e ci permetterà di leggere i dati inviati dal client 

const fs = require('fs');//richiama libreria fs
let lib = require('./CoppolaKCorvitto.js'); //assegna il file alla variabile "lib". Il percorso indica che il modulo si trova nella stessa cartella del file corrente.

let jsonData = lib.readFile('./cartella/person.json');//"readFile" sarebbe che va a leggere il contenuto del file "person.json" e Il contenuto viene assegnato alla variabile 
const app = express(); //viene assegnata alla variabile 'app' Express e rappresenta il nostro server web.
const jsonFilePath = './cartella/person.json';// assegna file "person.json" alla costante "jsonFilePath

app.use('/form', express.static(path.join(__dirname, 'form'))); // serve a fornire l'accesso al file form.html presente nella cartella "form"
app.use(bodyParser.urlencoded({ extended: true }));//consente al server di leggere i dati inviati dal client

//req richiesta res risposta
app.get('/', (req, res) => { //Quando si accede alla homepage del sito, viene restituito il file 'form.html'1 pagina 
  res.sendFile(path.join(`${__dirname}/form/form.html`));// 'sendFile'è una funzione  inviare il contenuto del file al client
});
app.get('/post', (req, res) => { // visualizzazione della pagina "view.html". "sendFile"  invia il file "view.html" 
  res.sendFile(path.join(`${__dirname}/view/view.html`));
});
app.get('/cartella/person.json', (req, res) => {
  res.sendFile(path.join(`${__dirname}/cartella/person.json`));
});
app.get('/viewPost', (req, res) => {
  res.sendFile(path.join(`${__dirname}/view/view.html`));
});
app.post('/viewPost', (req, res) => {
  res.redirect((path.join(`/viewPost`)));
});
app.post('/add', (req, res) => { //quando vengono inseriti i dati in input Il codice accede ai dati e li assegna a due variabili, "nickname" e "commento". 
  const nickname = { //Qui viene creato un oggetto "nickname" contenente le informazioni ricevute.
    nickname: req.body.nickname,
    commento: req.body.commento
  };
  let data = JSON.parse(fs.readFileSync(jsonFilePath));//legge il contenuto del file JSON situato nel jsonFilePath utilizzando fs lo insersce nell'oggeto che viene assegnato alla variabile data 
  lib.addElementToJSON(data, nickname); //aggiunge a data l'oggetto nickname che contine nome e commento
  lib.writeFileJSON('./cartella/person.json', data);//e la scrive nel fil person
  
  res.redirect((path.join(`/post`)));//indirizza alla pagina post
});
app.listen(3000, () => {
  console.log('Server started on port 3000');
});

